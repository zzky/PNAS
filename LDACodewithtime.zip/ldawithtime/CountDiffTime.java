package ldawithtime;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.HashMap;

public class CountDiffTime {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		int topicNum = 10;
		String explicitTopicPath = "D:\\�콻\\2015����update\\LDA\\t\\explicitTopic.csv";
		String yearPath = "D:\\�콻\\2015����update\\LDA\\t\\epidemiology_0324\\year.txt";
		HashMap<String,ArrayList<Integer>> hm = new HashMap<String,ArrayList<Integer>>();
		BufferedReader brYear = new BufferedReader(new FileReader(yearPath));
		BufferedReader brTopic = new BufferedReader(new FileReader(explicitTopicPath));

		String yearS = "";
		String topicS = "";
		while((yearS=brYear.readLine())!=null)
		{
//			if(yearS.equals("Adva"))
//			{
//				System.out.println(yearS);
//			}
			topicS = brTopic.readLine();	
			//System.out.println(topicS);
			String[] topic = topicS.split(" ",-1);
			for(int i=0;i<topic.length;i++)
			{
				topic[i] = topic[i].substring(topic[i].lastIndexOf("(")+1,topic[i].length()-1);
			}
			if(!hm.containsKey(yearS))
			{
				ArrayList<Integer> al = new ArrayList<Integer>();
				for(int i=0;i<topicNum;i++)
				{
					al.add(0);
				}
				hm.put(yearS, al);
			}
			for(String z : topic)
			{
				ArrayList<Integer> al = hm.get(yearS);
				al.set(Integer.parseInt(z),al.get(Integer.parseInt(z))+1);
				hm.put(yearS, al);
			}
			
		}
		brYear.close();
		brTopic.close();
		System.out.print("year");
		 for(int i=0;i<topicNum;i++)
		 {
			 System.out.print(" topic"+i);
		 }
		 System.out.println();
		for (String key : hm.keySet()) {  
			   System.out.print(key); 
			   for(int z : hm.get(key))
			   {
				   System.out.print(" "+z);
			   }
			   System.out.println();
			  }  
	}

}
