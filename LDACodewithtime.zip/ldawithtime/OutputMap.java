package ldawithtime;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.HashMap;

public class OutputMap {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception{
		int topicNum = 10;
		String explicitTopicPath = "C:\\Users\\syx\\Desktop\\tang\\ieee\\ieee\\explicitTopic.csv";
		String yearPath = "C:\\Users\\syx\\Desktop\\tang\\ieee\\ieee\\year.txt";
		BufferedReader brYear = new BufferedReader(new FileReader(yearPath));
		BufferedReader brTopic = new BufferedReader(new FileReader(explicitTopicPath));
		String[][] output = new String[17][topicNum];
		for(int i=0;i<17;i++)
		{
			for(int j=0;j<topicNum;j++)
			{
				output[i][j]="";
			}
		}
		String yearS = "";
		String topicS = "";
		while((yearS=brYear.readLine())!=null)
		{
			topicS = brTopic.readLine();			
			String[] word_topic = topicS.split(" ",-1);
			String word = "";
			int topic = 0;
			for(int i=0;i<word_topic.length;i++)
			{
				word = word_topic[i].substring(0,word_topic[i].lastIndexOf("("));
				topic = Integer.parseInt(word_topic[i].substring(word_topic[i].lastIndexOf("(")+1,word_topic[i].length()-1));
				output[Integer.parseInt(yearS)-2001][topic] = output[Integer.parseInt(yearS)-2001][topic] + " " + word;		
			}
		}
		brYear.close();
		brTopic.close();
		String outPath = "C:\\Users\\syx\\Desktop\\tang\\ieee\\ieee\\��ϸ���.txt";
		BufferedWriter bw = new BufferedWriter(new FileWriter(outPath));
		for(int i=0;i<17;i++)
		{
			for(int j=0;j<topicNum;j++)
			{
				bw.write(""+(i+2001)+"������"+j+":");
				bw.write(output[i][j]);
				bw.newLine();
			}
		}
		bw.close();
	}

}
